import React from 'react'

const page = () => {
  return (
    <div>
      Currencies
    </div>
  )
}

export default page
