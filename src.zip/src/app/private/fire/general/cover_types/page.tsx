import React from 'react'

const page = () => {
  return (
    <div>
      Cover types
    </div>
  )
}

export default page
