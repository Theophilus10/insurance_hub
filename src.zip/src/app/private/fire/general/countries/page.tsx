import React from 'react'

const page = () => {
  return (
    <div>
      countries
    </div>
  )
}

export default page
