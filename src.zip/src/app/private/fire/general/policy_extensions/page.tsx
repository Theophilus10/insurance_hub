import React from 'react'

const page = () => {
  return (
    <div>
      Policy extensions
    </div>
  )
}

export default page
