import React from 'react'

const page = () => {
  return (
    <div>
      banks
    </div>
  )
}

export default page
