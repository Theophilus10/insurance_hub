import React from 'react'

const page = () => {
  return (
    <div>
      Shipping types
    </div>
  )
}

export default page
