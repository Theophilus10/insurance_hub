import React from 'react'

const page = () => {
  return (
    <div>
      carriers
    </div>
  )
}

export default page
