import React from 'react'

const page = () => {
  return (
    <div>
      exchange rates
    </div>
  )
}

export default page
