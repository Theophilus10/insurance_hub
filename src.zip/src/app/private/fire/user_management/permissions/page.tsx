import React from 'react'

const page = () => {
  return (
    <div>
      permissions
    </div>
  )
}

export default page
