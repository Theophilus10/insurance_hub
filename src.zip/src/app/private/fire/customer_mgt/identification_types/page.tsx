import React from 'react'

const page = () => {
  return (
    <div>
      identification types
    </div>
  )
}

export default page
