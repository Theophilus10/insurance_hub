import React from 'react'

const page = () => {
  return (
    <div>
      Users
    </div>
  )
}

export default page
