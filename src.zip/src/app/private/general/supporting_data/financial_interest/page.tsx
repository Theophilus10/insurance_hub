import React from 'react'

const page = () => {
  return (
    <div>
      financial insterest
    </div>
  )
}

export default page
