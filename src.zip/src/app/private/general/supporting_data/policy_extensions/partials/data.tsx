import format from "date-fns/format";

export const data = [
  {
    id: 1,
    code: "PE001",
    name: "War, Riots, Strike & Civil Commotion",
    created_at: format(new Date(), "dd MMM yyy"),
  },
];
