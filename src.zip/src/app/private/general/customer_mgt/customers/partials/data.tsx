import format from "date-fns/format";


export const data = [
  {
    id: 1,
    full_name: "Evans office",
    customer_type: "Individual",
    customer_category: "Individual",
    occupation: "Self Employed",
    phone: "122345667",
    created_at: format(new Date(), 'dd MMM yyy'),
  },
  {
    id: 2,
    full_name: "Evans office",
    customer_type: "Individual",
    customer_category: "Individual",
    occupation: "Self Employed",
    phone: "122345667",
    created_at: format(new Date(), 'dd MMM yyy'),
  },
  {
    id: 3,
    full_name: "Evans office",
    customer_type: "Individual",
    customer_category: "Individual",
    occupation: "Self Employed",
    phone: "122345667",
    created_at: format(new Date(), 'dd MMM yyy'),
  },
  {
    id: 4,
    full_name: "Evans office",
    customer_type: "Individual",
    customer_category: "Individual",
    occupation: "Self Employed",
    phone: "122345667",
    created_at: format(new Date(), 'dd MMM yyy'),
  },
  {
    id: 5,
    full_name: "Evans office",
    customer_type: "Individual",
    customer_category: "Individual",
    occupation: "Self Employed",
    phone: "122345667",
    created_at: format(new Date(), 'dd MMM yyy'),
  },
];
